# UI components
print('Mirror UI')