# Fusion archetypes config
FUSION_ARCHETYPES = {}