# Core echo logic
print('Mirror Echo Logic')